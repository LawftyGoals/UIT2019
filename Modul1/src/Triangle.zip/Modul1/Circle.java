package Modul1;

public class Circle extends GeometricObject{

    int circle = 0;

    Circle(int i){
        this.circle = i;
    }

}
